exports.getList = (req, res, next)=>{
    //cần có view
    res.render('sanpham/list');
}

exports.addSP = (req, res, next)=>{
    res.render('sanpham/add');
}



