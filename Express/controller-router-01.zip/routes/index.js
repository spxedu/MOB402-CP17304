var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express',
                   hoTen:'ABC', gioiTinh:1});
});

// router.get('/sp', (req,res,next)=>{
//     console.log("Gửi dữ liệu dạng Query ");
//     console.log(req.url);
//     console.log(req.query);
// });  //chạy thử http://localhost:3000/sp?id=5&group=3

// router.get('/sp/:id?', (req,res,next)=>{
//   console.log("Gửi dữ liệu dạng Params ");
//   console.log(req.url);
//   console.log(req.params);
//   res.send(req.params);
// });  //chạy thử http://localhost:3000/sp/5 

// router.post("/add-sp",(req,res,next)=>{
//    console.log("Dữ liệu post");
//    console.log(req.body);
//    res.send(req.body);
// });



module.exports = router;
