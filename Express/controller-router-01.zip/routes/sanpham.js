var express = require('express');
var router = express.Router();
var spController = require('../controllers/sanpham.controller')
// lấy ds :
router.get('/',spController.getList );

router.get('/add', spController.addSP );



//luôn nhớ có export 
module.exports = router;