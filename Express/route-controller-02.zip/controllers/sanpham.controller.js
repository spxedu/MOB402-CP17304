exports.getList = (req, res, next)=>{
    //cần có view
    let hoTen = "Nguyen Van A";
    let objSP = { id: 5, name:"Điện thoại"};

    res.render('sanpham/list', { user: hoTen, sp: objSP });
    // ejs.co 
}

exports.addSP = (req, res, next)=>{

    let ten_sp = '';
    if(req.method == 'POST'){
        // sự kiện post:
         ten_sp = req.body.ten_sp;
    }
    res.render('sanpham/add',{ten_sp: ten_sp});
}



